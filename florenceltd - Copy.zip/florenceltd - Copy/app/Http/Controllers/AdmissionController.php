<?php

namespace App\Http\Controllers;

use App\Admission;
use Illuminate\Http\Request;

class AdmissionController extends Controller
{
    public function index()
    {
        return view('front.admission.index');
    }

    public function create()
    {
        return view('front.admission.create');
    }


    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'number1' => 'required',
            'number2' => 'required',
            'gender' => 'required',
            'mother_name' => 'required',
            'father_name' => 'required',
            'board_name' => 'required',
            'roll_number' => 'required',
            'registration_number' => 'required',
            'passing_year' => 'required',
            'gpa' => 'required',
            'institute_name' => 'required',
            'hsc_board_name' => 'required',
            'hsc_registration_number' => 'required',
            'hsc_roll_number' => 'required',
            'hsc_passing_year' => 'required',
            'hsc_gpa' => 'required',
            'hsc_institute_name' => 'required',
            'branch_name' => 'required',
        ]);

        Admission::create($request->all());
        //return $request;
        return redirect()->back()->with(['message'=>'Your Information Successfully Sent to Florence Authority']);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Admission $admission
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       if (!is_null(Admission::find($id))){
           return view('front.admission.show' ,['reg_student'=>Admission::find($id)]);
       }
    }

    public function registeredStudent()
    {
        return view('admin.admission.index', ['reg_students'=>Admission::all()]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Admission $admission
     * @return \Illuminate\Http\Response
     */
    public function edit(Admission $admission)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Admission $admission
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Admission $admission)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Admission $admission
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (!is_null(Admission::find($id))){
            Admission::destroy($id);
        }

        return redirect(route('admission.index'))->with(['message' => ' Registration DELETED Successfully']);

    }
}
