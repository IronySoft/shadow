<?php

namespace App\Http\Controllers;

use App\Text;
use Illuminate\Http\Request;

class TextController extends Controller
{
    public function index()
    {
        return view('admin.text.index', ['my_texts' => Text::all()]);
    }

    public function create()
    {
        return view('admin.text.create');
    }


    public function store(Request $request)
    {
        $this->validate($request, [
            'text' => 'required',

        ]);


        $Text = new Text();
        $Text->text = $request->text;

        $Text->save();

        return redirect(route('text.index'))->with(['message' => 'New text added Successfully']);

    }

    public function show($id)
    {
        return view('admin.text.show', ['text' => Text::findOrFail($id)]);
    }


    public function edit($id)
    {
        $row = Text::find($id);
        if (!is_null($row)) {
            if ($row->status == 0) {
                $row->status = 1;
            } else {
                $row->status = 0;
            }
        }
        $row->update();
        return redirect()->back();
    }


    public function update(Request $request, $id)
    {
        $check = Text::findOrFail($id);
        if (!is_null($check)) {
            $check->text = $request->text;
            $check->update();
            return redirect(route('text.index'))->with(['message' => 'Text Updated Successfully']);
        }
        return redirect(route('text.index'))->with(['message' => 'Something wrong happened!']);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Text $text
     * @return \Illuminate\Http\Response
     */
    public function destroy(Text $text)
    {
        $check = Text::findOrFail($text->id);
        if (!is_null($check)) {
            Text::destroy($text->id);
            return redirect(route('text.index'))->with(['message' => 'Text DELETED Successfully']);
        }
        return redirect(route('text.index'))->with(['message' => 'Not Changed']);

    }
}
