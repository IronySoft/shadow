<?php

namespace App\Http\Controllers;

use App\AboutUs;
use App\Blog;
use App\Course;
use App\FlorenceTeam;
use App\MissionVision;
use App\Notice;
use App\Project;
use App\Slider;
use App\Testimonial;
use App\Text;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ViewController extends Controller
{
    public function index()
    {
        return view('front.home.index', [
            'sliders' => Slider::all(),
            'text' => Text::all()->where('id', '=', 1),
            'blogs' => DB::table('blogs')->orderBy('created_at', 'DESC')->paginate(3),
            'projects' => DB::table('projects')->paginate(6),


        ]);
    }

    public function index2()
    {
        return view('front.home.index2');
    }

    public function blogIndex()
    {
        return view('front.blog.index', [
            'blogs' => DB::table('blogs')->orderBy('created_at', 'DESC')->paginate(6),
            'headLines' => DB::table('blogs')->select('title')->paginate(5),
//            'olderBlogs' => DB::table('blogs')->orderBy('created_at', 'ASC')->paginate(5),

        ]);
    }

    public function noticeIndex()
    {
        return view('front.notice.index', ['notices' => DB::table('notices')->orderBy('created_at', 'DESC')->paginate(6)]);
    }

    public function bookDetails($id)
    {
        if (!is_null(Notice::find($id))){
            return view('front.notice.details', ['book' => Notice::find($id)]);
        }else{
            return redirect()->back();
        }

    }

    public function blogDetails($id)
    {
        if (!is_null(Blog::find($id))) {
            return view('front.blog.details', [ 'blog' => Blog::find($id) ]);
        } else {
            return redirect()->back();
        }
    }

    public function aboutIndex($id)
    {
        if (!is_null(AboutUs::find($id))) {
            return view('front.about.index', [
                'about' => AboutUs::find($id),
//            'texts' => Text::all(),
//            'florenceTeams' => FlorenceTeam::all(),
//            'goals' => MissionVision::all(),

            ]);
        } else {
            return redirect()->back();
        }

    }

    public function courseIndex($id)
    {
        if (!is_null(Course::find($id))) {
            return view('front.course.index', ['course' => Course::find($id)]);
        } else {
            return redirect()->back();
        }
    }

//    public function courseShow($id)
//    {
//        if (!is_null(Course::find($id))){
//            return view('front.course.show', ['course' => Course::find($id)]);
//        }else {
//            return redirect()->back();
//        }
//
//    }

    public function testimonialIndex()
    {
        return view('front.testimonial.index', ['testimonials' => Testimonial::all()]);
    }

    public function galleryIndex()
    {
        return view('front.gallery.index', ['projects' => DB::table('projects')->get()]);
    }


    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }


    public function update(Request $request, $id)
    {
        //
    }


    public function destroy($id)
    {
        //
    }
}
