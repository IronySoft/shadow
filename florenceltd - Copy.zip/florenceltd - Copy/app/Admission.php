<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admission extends Model
{
    protected $fillable = [
        'name', 'gender', 'mother_name', 'father_name','number1', 'number2','branch_name',
        'board_name', 'roll_number','registration_number', 'passing_year', 'gpa', 'institute_name',
        'hsc_board_name', 'hsc_roll_number','hsc_registration_number', 'hsc_passing_year', 'hsc_gpa', 'hsc_institute_name',
    ];
}
