<?php

namespace App\Providers;

use App\AboutUs;
use App\Address;
use App\Course;
use App\Student;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {

    }


    public function boot()
    {
        //Schema::defaultStringLength(191);
        View()->composer('*', function ($view) {
            $view->with('address', Address::all()->where('id', '=', 1));
        });

        View()->composer('*', function ($view) {
            $view->with('students', Student::paginate(8));
        });

        View()->composer('*', function ($view) {
            $view->with('courses', Course::all());
        });
        View()->composer('*', function ($view) {
            $view->with('about_us', AboutUs::all());
        });
        View()->composer('*', function ($view) {
            $view->with('myNotices', DB::table('notices')->orderBy('created_at', 'DESC')->paginate(3));
        });
        View()->composer('*', function ($view) {
            $view->with('postTitles', DB::table('blogs')->paginate(5));
        });
        View()->composer('*', function ($view) {
            $view->with('footerAddress', DB::table('addresses')->where('status','=',0)->get());
        });
    }
}
