<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FlorenceTeam extends Model
{
    //
}
