<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdmissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admissions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->text('name');
            $table->text('gender');
            $table->text('mother_name');
            $table->text('father_name');
            $table->text('number1');
            $table->text('number2');

            $table->text('board_name');
            $table->text('roll_number');
            $table->text('registration_number');
            $table->text('passing_year');
            $table->text('gpa');
            $table->text('institute_name');


            $table->text('hsc_board_name');
            $table->text('hsc_roll_number');
            $table->text('hsc_registration_number');
            $table->text('hsc_passing_year');
            $table->text('hsc_gpa');
            $table->text('hsc_institute_name');

            $table->text('branch_name');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admissions');
    }
}
