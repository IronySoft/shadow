<?php $__env->startSection('body'); ?>
    <div id="body-wrapper">

        <!-- Services
        ================================================== -->
        <div id="services-wrapper">
            <div id="services">
                <div class="inner-wrapper">
                    <div class="container">
                        <h2>Check out <span>Shadownic's Services</span></h2>

                        <div class="row">
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="service-box service-fold">
                                    <i class="hippo-icon-photo"></i>

                                    <h3>Graphics Design</h3>

                                    <p>
                                        How communication happens. We make your information scroll.We bring your
                                        information alive. </p>
                                </div>
                            </div>

                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="service-box service-fold">
                                    <i class="hippo-icon-diamond"></i>

                                    <h3>Web Development</h3>

                                    <p>
                                        By driving the revolution we raise your business and take you forward. The right
                                        technology, right away. </p>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="service-box service-fold">
                                    <i class="hippo-icon-lightbulb"></i>

                                    <h3>Bulk SMS/Mass SMS
                                    </h3>

                                    <p>
                                        Shadownic Provides Bulk messaging of large numbers of SMS messages for delivery
                                        to mobile phone terminals. </p>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="service-box service-fold">
                                    <i class="hippo-icon-beaker"></i>

                                    <h3>Domain Hosting</h3>

                                    <p>
                                        Shadownic specialize in hosting domain names for individuals and companies. </p>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="service-box service-fold">
                                    <i class="hippo-icon-pencil"></i>

                                    <h3>E-mail Hosting</h3>

                                    <p>
                                        An email hosting service is an Internet hosting service that operates email
                                        servers. </p>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="service-box service-fold">
                                    <i class="hippo-icon-paper-plane"></i>

                                    <h3>Professional IT Training</h3>

                                    <p>
                                        We have regular training programs offering here and we also design customize
                                        training as our client's request. </p>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="service-box service-fold">
                                    <i class="hippo-icon-star"></i>

                                    <h3>IT Consultancy</h3>

                                    <p>
                                        Shadownic IT consultants deliver business model and strategies, in order to
                                        fortify their decision-making. </p>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <div class="service-box service-fold">
                                    <i class="hippo-icon-heart"></i>

                                    <h3>Branding</h3>

                                    <p>
                                        Nationwide is on your side. Our technology and expertise for your
                                        Company/Product Branding. </p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/#services-->

        <!-- Portfolio
        ================================================== -->
        <div id="portfolio-wrapper">
            <div id="portfolio">
                <div class="inner-wrapper">
                    <div class="row">
                        <div class="container">
                            <h2>Check out our <span>Products</span></h2>

                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <div id="portfolio-container">
                                        <div id="portfolio-items">

                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-photo"></i>

                                                    <h3>Education Management System</h3>

                                                    <p>
                                                        EMS digital Education Management System is the all-in-one school
                                                        operating system.
                                                        Classrooms gain access to a library of teaching. </p>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-diamond"></i>

                                                    <h3>ERP Solution</h3>

                                                    <p>
                                                        Enterprise resource planning (ERP) for business process management
                                                        software that allows
                                                        an organization to use a system. </p>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-lightbulb"></i>

                                                    <h3>Access Control and Time Attendance
                                                    </h3>

                                                    <p>
                                                        Shadownic Provides Bulk messaging of large numbers of SMS messages for delivery
                                                        to mobile phone terminals. </p>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-beaker"></i>

                                                    <h3>Access Control &amp; Time Attendance</h3>

                                                    <p>
                                                        A security technique that regulates who or what can view or use resources
                                                        in a computing
                                                        environment.                                                     </p>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-pencil"></i>

                                                    <h3>Library Management System</h3>

                                                    <p>
                                                        An integrated library system for enterprise resource planning system for
                                                        a library, used to
                                                        track items owned, orders made, bills paid, and patrons who have
                                                        borrowed. </p>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-paper-plane"></i>

                                                    <h3>Website Development</h3>

                                                    <p>
                                                        We use the best breed of open source tools and technologies to develop
                                                        web applications. </p>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-star"></i>

                                                    <h3>Network and Security Solution</h3>

                                                    <p>
                                                        An information security management system (ISMS) that a set of policies
                                                        and procedures for
                                                        systematically managing an organization's sensitive data. </p>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-heart"></i>

                                                    <h3>Queue Management System</h3>

                                                    <p>
                                                        A queue management system to control queues. Queues of people form in
                                                        various situations and
                                                        locations in a queue area. </p>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-heart"></i>

                                                    <h3>Payroll and HR Solution</h3>

                                                    <p>
                                                        A payroll is a company's list of its employees, but the term is commonly
                                                        used to refer to:
                                                        the total amount of money that a company pays to its employees.</p>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-xs-12">
                                                <div class="service-box service-fold">
                                                    <i class="hippo-icon-heart"></i>

                                                    <h3>Video Serveillance System</h3>

                                                    <p>
                                                        Closed-circuit television, also known as video surveillance, of video
                                                        cameras to transmit a
                                                        signal to a specific place, on a limited set of monitors.</p>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="portfolio-directions">
                                        <span class="prev-items rounded"><i class="fa fa-angle-left"></i></span>
                                        <span class="next-items rounded"><i class="fa fa-angle-right"></i></span>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/#portfolio-->

        <!-- About us
        ================================================== -->
        <div id="aboutus-wrapper">
            <div id="aboutus">
                <div class="inner-wrapper">
                    <div class="row">
                        <div class="container">
                            <h2>Read more <span> About us</span></h2>

                            <div class="row contents">
                                <div class="col-md-6">
                                    <p> Shadownic is one of the leading Information Technology Solution Companies in
                                        Bangladesh with a strong talented team that provides extensive range of products
                                        and services. It has built a reputation for innovation and delivering excellence
                                        in development and design.</p>
                                    <p>
                                        Incorporated in United Kingdom, United Arab Emirates, France and in Bangladesh, Shadownic Innovation offers the most advanced IT solutions, supporting full business cycle: preliminary consulting, system development and deployment, quality assurance and 24x7 supports.
                                    </p>

                                    <p>
                                        Shadownic is committed to building long lasting strategic partnerships with its clients to ensure extremely competitive and affordable prices, timely delivery and measurable business results.
                                    </p>

                                    <p>
                                        At Shadownic, our engineers are the cream-of-the crop. In fact, they all have engineering or computer science degrees from top universities, which is rare in our industry. Our team is passionate about solving complex problems quickly and effectively, helping our customers grow their businesses, and providing the highest-quality customer experience.
                                    </p>
                                </div>
                                <div class="col-md-6">
                                    <h3>Our Skills</h3>

                                    <p> We build comprehensive and customize web-based Automation and Management Software which has been designed and tailored specially for large scale industry and educational institutes to assure smooth administration and management of various scholastic and non scholastic activities.</p>

                                    <div class="progress-bars">
                                        <div class="skill-progress" data-skill="95%">Graphics</div>
                                        <div class="skill-progress" data-skill="99%">Photoshop</div>

                                        <div class="skill-progress" data-skill="85%">HTML-CSS</div>
                                        <div class="skill-progress" data-skill="90%">PHP</div>
                                    </div>
                                    <div class="connect">
                                        <h3>Connect with us</h3>

                                        <div class="social-shares">
                                            <ul>
                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                                <li><a href="#"><i class="fa fa-tumblr"></i></a></li>
                                                <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/#about-us-->


        <!--/#team-->

        <!-- Client
        ================================================== -->
        <div id="client-wrapper">
            <div id="client">
                <div class="inner-wrapper">
                    <div class="row">
                        <div class="container">
                            <h2>Check out our <span>Clients</span></h2>

                            <div class="row">
                                <div id="clients">
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/1.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/2.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/3.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/4.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/5.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/6.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/7.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/8.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/9.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/10.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/11.png" alt=""></a>
                                    </div>
                                    <div class="col-md-2 col-sm-3 col-xs-4">
                                        <a href="#"><img src="<?php echo e(asset('/')); ?>front/images/clients/12.png" alt=""></a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /#client -->


        <!--/#blog-->

        <!-- Contact
        ================================================== -->
        <div id="contact-wrapper">
            <div id="contact">
                <div class="inner-wrapper">
                    <div class="row">
                        <div class="container">
                            <h2><span>Contact us</span> Now</h2>

                            <div class="row">
                                <div class="col-md-12 col-sm-6">
                                    
                                    
                                    

                                    <div class="row">
                                        <div class="col-md-12 col-sm-12">
                                            <div class="mapouter">
                                                <div class="gmap_canvas">
                                                    <iframe width="1080" height="500" id="gmap_canvas"
                                                            src="https://maps.google.com/maps?q=sabdar%20ali%20road%20agrabad&t=&z=15&ie=UTF8&iwloc=&output=embed"
                                                            frameborder="0" scrolling="no" marginheight="0"
                                                            marginwidth="0"></iframe>
                                                    <a href="https://www.embedgooglemap.org">embedgooglemap.org</a>
                                                </div>
                                                <style>.mapouter {
                                                        position: relative;
                                                        text-align: right;
                                                        height: 500px;
                                                        width: 1080px;
                                                    }

                                                    .gmap_canvas {
                                                        overflow: hidden;
                                                        background: none !important;
                                                        height: 500px;
                                                        width: 1080px;
                                                    }</style>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="contact-info">
                                        <ul>
                                            <li class="first">
                                                <p><i class="fa fa-map-marker fa-2"></i> ShadowNic Ltd.</p>

                                                <p> Sabdar Ali Road, Agrabad C/A, Chittagong 4000.</p>
                                            </li>
                                            <li class="second">
                                                <p><i class="fa fa-phone fa-2"></i> +0088776 69 900</p>

                                                <p><i class="fa fa-envelope fa-2"></i> shadownic6@gmail.com </p>
                                            </li>
                                            <li class="third">
                                                <p><i class="fa fa-clock-o fa-2"></i> Saturday - Thursday</p>

                                                <p> 9:00 AM - 9:00 AM</p>
                                            </li>
                                        </ul>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="message-box">
                                        <h3>Send Message</h3>

                                        <form method="post" action="#">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control" placeholder="Name">
                                                </div>
                                                <div class="col-md-6">
                                                    <input type="email" class="form-control" placeholder="Email">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <textarea class="form-control" placeholder="Message"></textarea>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <input type="submit" class="readmore send-button"
                                                           value="Send Message">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/#contact-wrapper-->
    </div>
    <!--/.body-wrapper-->

    <!-- Bottom
    ================================================== -->
    <div id="bottom">
        <div class="row">
            <a id="to-top" href="#main-slider"><i class="fa fa-long-arrow-up"></i></a>

            <div class="container">
                <div class="col-xs-6">
                    <div class="social-shares">
                        <ul>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-tumblr"></i></a></li>
                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="copyright">
                        <p>Design by Shadownic Ltd. Copyright &copy; 2019
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/#bottom-->

    <!-- Modal Window
    ================================================== -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Xampp\htdocs\Git Project\shadownic\shadownic\resources\views/front/index.blade.php ENDPATH**/ ?>