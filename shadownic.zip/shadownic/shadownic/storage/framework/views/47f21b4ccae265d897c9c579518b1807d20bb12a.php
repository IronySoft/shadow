<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>Shadownic IT Firm</title>

    <link href="<?php echo e(asset('/')); ?>front/css/reset.css" rel="stylesheet"/>
    <link href="http://fonts.googleapis.com/css?family=Lato:100,300,400,700" rel="stylesheet">
    <link href="<?php echo e(asset('/')); ?>front/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo e(asset('/')); ?>front/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('/')); ?>front/css/fontello/<?php echo e(asset('/')); ?>front/css/fontello.css" rel="stylesheet">
    <link href="<?php echo e(asset('/')); ?>front/css/jquery.bxslider.css" rel="stylesheet">
    <link href="<?php echo e(asset('/')); ?>front/css/style.css" rel="stylesheet">
    <link href="<?php echo e(asset('/')); ?>front/css/media-query.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="<?php echo e(asset('/')); ?>front/js/html5shiv.js"></script>
    <script src="<?php echo e(asset('/')); ?>front/js/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<div class="body-inner-wrapper">
    <!-- Navbar
    ================================================== -->
    <div id="menu-wrapper" class="navbar-wrapper">
        <div class="inner-container">
            <div id="navigation-bar" class="navbar navbar-inverse navbar-static-top" role="navigation">
                <div class="container">
                    <div class="navbar-header">
                        <div>
                            <button type="button" class="navbar-toggle" data-toggle="collapse"
                                    data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a id="logo" class="navbar-brand" href="index.html"><img class="" src="<?php echo e(asset('/')); ?>front/images/logo.png"
                                                                                     alt=""></a>
                        </div>
                    </div>
                    <div id="menu" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-left">
                            <li class="active home"><a href="#main-slider"> Home</a></li>
                            <li class="service"><a href="#services-wrapper">Services</a></li>
                            <li class="portfolio"><a href="#portfolio-wrapper">Products</a></li>
                            <li class="about"><a href="#aboutus-wrapper">About</a></li>
                            <li class="client"><a href="#client-wrapper">Clients</a></li>
                            <li class="contact"><a href="#contact-wrapper">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Slideshow
    ================================================== -->
    <div id="main-slider" class="no-margin">
        <div class="carousel slide wet-asphalt">
            <!--
            <ol class="carousel-indicators">
                <li data-target="#main-slider" data-slide-to="0" class="active"></li>
                <li data-target="#main-slider" data-slide-to="1"></li>
                <li data-target="#main-slider" data-slide-to="2"></li>
            </ol>
            -->
            <div class="carousel-inner">
                <div class="item active" style="background-image: url(<?php echo e(asset('/')); ?>front/images/slider/slide1.jpg)">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="carousel-content centered">
                                    <h2 class="animation animated-item-1">We Design <span>Creative Website</span></h2>

                                    <h2 class="animation animated-item-2">For Enterprising People</h2>
                                    <br>
                                    <span class="content-nav">
									<a href="#services-wrapper" class="animation animated-item-3">Go</a>
								</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/.item-->
                <div class="item" style="background-image: url(<?php echo e(asset('/')); ?>front/images/slider/slide2.jpg)">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="carousel-content center centered">
                                    <h2 class="animation animated-item-1">Easy and <span>Customizable</span></h2>

                                    <h2 class="animation animated-item-2">Responsive Theme</h2>
                                    <br>
                                    <span class="content-nav">
									<a href="#services-wrapper" class="animation animated-item-3">Go</a>
								</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/.item-->

                <div class="item">
                    <video id="video_background" preload="auto" autoplay loop="loop" muted="muted" controls>
                        <source src="<?php echo e(asset('/')); ?>front/videos/splash.webm" type="video/webm">
                        <source src="<?php echo e(asset('/')); ?>front/videos/splash.mp4" type="video/mp4">
                        <source src="<?php echo e(asset('/')); ?>front/videos/splash.ogv" type="video/ogg">
                        Video not supported
                    </video>

                    <div id="video_pattern"></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="carousel-content centered">

                                    <h2 class="animation animated-item-1">The Best <span>HTML5 Theme</span></h2>

                                    <h2 class="animation animated-item-2">You Have Ever Seen</h2>

                                    <br>
                                    <span class="content-nav">
                                    <a href="#services-wrapper" class="animation animated-item-3">Go</a>
                                </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/.item-->
            </div>
            <!--/.carousel-inner-->
        </div>
        <!--/.carousel-->
        <a class="prev hidden-xs rounded" href="#main-slider" data-slide="prev">
            <i class="fa fa-angle-left"></i>
        </a>
        <a class="next hidden-xs rounded" href="#main-slider" data-slide="next">
            <i class="fa fa-angle-right"></i>
        </a>
    </div>
    <!--/#main-slider-->

    <?php echo $__env->yieldContent('body'); ?>

</div>
<!--/.body-inner-wrapper-->

<script src="<?php echo e(asset('/')); ?>front/js/jquery.min.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/jquery.easing.min.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/jquery.bxslider.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/jquery.nicescroll.min.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/waypoints.min.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/themehippo.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script src="<?php echo e(asset('/')); ?>front/js/script.js"></script>

</body>
</html>
<?php /**PATH H:\Xampp\htdocs\Git Project\shadownic\shadownic\resources\views/front/master.blade.php ENDPATH**/ ?>