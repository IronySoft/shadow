<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shadow extends Model
{
    //
}
