<?php

namespace App\Http\Controllers;

use App\Shadow;
use Illuminate\Http\Request;

class ShadowController extends Controller
{

    public function index()
    {
        return view('front.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Shadow $shadow
     * @return \Illuminate\Http\Response
     */
    public function show(Shadow $shadow)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Shadow $shadow
     * @return \Illuminate\Http\Response
     */
    public function edit(Shadow $shadow)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Shadow $shadow
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Shadow $shadow)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Shadow $shadow
     * @return \Illuminate\Http\Response
     */
    public function destroy(Shadow $shadow)
    {
        //
    }
}
